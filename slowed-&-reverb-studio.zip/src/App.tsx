import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Pause, 
  Upload, 
  Download, 
  Settings, 
  Music, 
  Volume2, 
  RotateCcw,
  Zap,
  Waves,
  Activity,
  Globe,
  Lock,
  Unlock,
  Sliders
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Knob } from './components/Knob';
import { Slider } from './components/Slider';
import { Waveform } from './Waveform';

// --- Audio Engine Constants ---
const EQ_FREQUENCIES = [60, 250, 1000, 4000, 12000];
const TABS = [
  { id: 'main', label: 'Main Reverb', icon: <Zap size={16} /> },
  { id: 'advanced', label: 'Advanced', icon: <Sliders size={16} /> },
  { id: 'eq', label: 'EQ', icon: <Activity size={16} /> },
  { id: 'orbit', label: '3D Orbit', icon: <Globe size={16} /> },
  { id: 'presets', label: 'Presets', icon: <Music size={16} /> },
];

export default function App() {
  // --- State ---
  const [activeTab, setActiveTab] = useState('main');
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isLocked, setIsLocked] = useState(true);
  const [fileName, setFileName] = useState<string | null>(null);

  // --- Audio Parameters ---
  const [speed, setSpeed] = useState(0.85);
  const [pitch, setPitch] = useState(-2);
  const [reverbAmount, setReverbAmount] = useState(0.6);
  const [preDelay, setPreDelay] = useState(20); // ms
  const [width, setWidth] = useState(100); // %
  const [dampingLF, setDampingLF] = useState(0);
  const [dampingHF, setDampingHF] = useState(0);
  const [eqGains, setEqGains] = useState([2, 0, 0, 0, 0]);
  const [outputGain, setOutputGain] = useState(0);
  const [orbitSpeed, setOrbitSpeed] = useState(0.5);
  const [oscillation, setOscillation] = useState(0.3);
  const [directionality, setDirectionality] = useState(0.8);

  // --- Audio Context Refs ---
  const audioCtx = useRef<AudioContext | null>(null);
  const sourceNode = useRef<AudioBufferSourceNode | null>(null);
  const gainNode = useRef<GainNode | null>(null);
  const reverbNode = useRef<ConvolverNode | null>(null);
  const preDelayNode = useRef<DelayNode | null>(null);
  const dampingLFNode = useRef<BiquadFilterNode | null>(null);
  const dampingHFNode = useRef<BiquadFilterNode | null>(null);
  const dryGain = useRef<GainNode | null>(null);
  const wetGain = useRef<GainNode | null>(null);
  const pannerNode = useRef<StereoPannerNode | null>(null);
  const eqNodes = useRef<BiquadFilterNode[]>([]);
  const outputGainNode = useRef<GainNode | null>(null);
  const startTimeRef = useRef(0);
  const offsetRef = useRef(0);
  const animationFrameRef = useRef(0);

  // --- Initialization ---
  useEffect(() => {
    audioCtx.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // Setup EQ
    eqNodes.current = EQ_FREQUENCIES.map((freq, i) => {
      const filter = audioCtx.current!.createBiquadFilter();
      filter.type = i === 0 ? 'lowshelf' : i === 4 ? 'highshelf' : 'peaking';
      filter.frequency.value = freq;
      filter.Q.value = 1;
      filter.gain.value = eqGains[i];
      return filter;
    });

    // Setup Reverb Path
    reverbNode.current = audioCtx.current.createConvolver();
    preDelayNode.current = audioCtx.current.createDelay(1.0);
    dampingLFNode.current = audioCtx.current.createBiquadFilter();
    dampingLFNode.current.type = 'highpass';
    dampingHFNode.current = audioCtx.current.createBiquadFilter();
    dampingHFNode.current.type = 'lowpass';
    
    dryGain.current = audioCtx.current.createGain();
    wetGain.current = audioCtx.current.createGain();
    
    // Setup Panner
    pannerNode.current = audioCtx.current.createStereoPanner();
    
    // Setup Output Gain
    outputGainNode.current = audioCtx.current.createGain();

    // Generate default impulse response
    generateImpulseResponse(2.5, 1.5).then(buffer => {
      if (reverbNode.current) reverbNode.current.buffer = buffer;
    });

    return () => {
      if (audioCtx.current) audioCtx.current.close();
      cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  // --- Audio Helpers ---
  const generateImpulseResponse = async (duration: number, decay: number) => {
    if (!audioCtx.current) return null;
    const sampleRate = audioCtx.current.sampleRate;
    const length = sampleRate * duration;
    const impulse = audioCtx.current.createBuffer(2, length, sampleRate);
    
    for (let channel = 0; channel < 2; channel++) {
      const channelData = impulse.getChannelData(channel);
      for (let i = 0; i < length; i++) {
        const n = i / length;
        channelData[i] = (Math.random() * 2 - 1) * Math.pow(1 - n, decay);
      }
    }
    return impulse;
  };

  const audioBufferToWav = (buffer: AudioBuffer) => {
    const numOfChan = buffer.numberOfChannels;
    const length = buffer.length * numOfChan * 2 + 44;
    const bufferArray = new ArrayBuffer(length);
    const view = new DataView(bufferArray);
    const channels = [];
    let i;
    let sample;
    let offset = 0;
    let pos = 0;

    // write WAVE header
    setUint32(0x46464952); // "RIFF"
    setUint32(length - 8); // file length - 8
    setUint32(0x45564157); // "WAVE"

    setUint32(0x20746d66); // "fmt " chunk
    setUint32(16); // length = 16
    setUint16(1); // PCM (uncompressed)
    setUint16(numOfChan);
    setUint32(buffer.sampleRate);
    setUint32(buffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
    setUint16(numOfChan * 2); // block-align
    setUint16(16); // 16-bit (hardcoded)

    setUint32(0x61746164); // "data" - chunk
    setUint32(length - pos - 4); // chunk length

    // write interleaved data
    for (i = 0; i < buffer.numberOfChannels; i++)
      channels.push(buffer.getChannelData(i));

    while (pos < length) {
      for (i = 0; i < numOfChan; i++) {
        // interleave channels
        sample = Math.max(-1, Math.min(1, channels[i][offset])); // clamp
        sample = (sample < 0 ? sample * 0x8000 : sample * 0x7fff) | 0; // scale to 16-bit signed int
        view.setInt16(pos, sample, true); // write 16-bit sample
        pos += 2;
      }
      offset++; // next source sample
    }

    return new Blob([bufferArray], { type: "audio/wav" });

    function setUint16(data: number) {
      view.setUint16(pos, data, true);
      pos += 2;
    }

    function setUint32(data: number) {
      view.setUint32(pos, data, true);
      pos += 4;
    }
  };

  const handleDownload = async () => {
    if (!audioBuffer || !audioCtx.current) return;

    const offlineCtx = new OfflineAudioContext(
      2,
      Math.ceil(audioBuffer.duration / speed * audioCtx.current.sampleRate),
      audioCtx.current.sampleRate
    );

    const source = offlineCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.playbackRate.value = speed;

    // EQ
    const eq = EQ_FREQUENCIES.map((freq, i) => {
      const filter = offlineCtx.createBiquadFilter();
      filter.type = i === 0 ? 'lowshelf' : i === 4 ? 'highshelf' : 'peaking';
      filter.frequency.value = freq;
      filter.gain.value = eqGains[i];
      return filter;
    });

    // Reverb Path
    const reverb = offlineCtx.createConvolver();
    reverb.buffer = await generateImpulseResponse(2.5, 1.5);
    const preDelayNodeOffline = offlineCtx.createDelay();
    preDelayNodeOffline.delayTime.value = preDelay / 1000;
    const dampLF = offlineCtx.createBiquadFilter();
    dampLF.type = 'highpass';
    dampLF.frequency.value = 100 + (dampingLF * -20); // mapping
    const dampHF = offlineCtx.createBiquadFilter();
    dampHF.type = 'lowpass';
    dampHF.frequency.value = 15000 + (dampingHF * 500); // mapping

    const dry = offlineCtx.createGain();
    const wet = offlineCtx.createGain();
    dry.gain.value = 1 - reverbAmount;
    wet.gain.value = reverbAmount;

    // Panner (Orbit)
    const panner = offlineCtx.createStereoPanner();
    const totalDuration = audioBuffer.duration / speed;
    const steps = 100;
    for (let i = 0; i <= steps; i++) {
      const time = (i / steps) * totalDuration;
      const angle = orbitSpeed * 0.05 * (time * 60);
      const pan = Math.sin(angle) * directionality;
      panner.pan.linearRampToValueAtTime(pan, time);
    }

    // Output Gain
    const output = offlineCtx.createGain();
    output.gain.value = Math.pow(10, outputGain / 20);

    // Connect
    let last: AudioNode = source;
    eq.forEach(node => {
      last.connect(node);
      last = node;
    });

    last.connect(dry);
    last.connect(preDelayNodeOffline);
    preDelayNodeOffline.connect(reverb);
    reverb.connect(dampLF);
    dampLF.connect(dampHF);
    dampHF.connect(wet);
    
    const mix = offlineCtx.createGain();
    dry.connect(mix);
    wet.connect(mix);
    
    mix.connect(panner);
    panner.connect(output);
    output.connect(offlineCtx.destination);

    source.start(0);
    const renderedBuffer = await offlineCtx.startRendering();
    const wavBlob = audioBufferToWav(renderedBuffer);
    const url = URL.createObjectURL(wavBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `slowed_reverb_${fileName || 'track'}.wav`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const updateAudioNodes = useCallback(() => {
    if (!audioCtx.current) return;

    // Update EQ
    eqNodes.current.forEach((node, i) => {
      node.gain.setTargetAtTime(eqGains[i], audioCtx.current!.currentTime, 0.05);
    });

    // Update Advanced Reverb
    if (preDelayNode.current) {
      preDelayNode.current.delayTime.setTargetAtTime(preDelay / 1000, audioCtx.current.currentTime, 0.05);
    }
    if (dampingLFNode.current) {
      // Damping LF: Highpass filter. 0dB = 20Hz, -24dB = 500Hz
      const freq = 20 + (Math.abs(dampingLF) * 20); 
      dampingLFNode.current.frequency.setTargetAtTime(freq, audioCtx.current.currentTime, 0.05);
    }
    if (dampingHFNode.current) {
      // Damping HF: Lowpass filter. 0dB = 20kHz, -24dB = 1kHz
      const freq = 20000 - (Math.abs(dampingHF) * 800);
      dampingHFNode.current.frequency.setTargetAtTime(freq, audioCtx.current.currentTime, 0.05);
    }

    // Update Reverb Mix
    if (dryGain.current && wetGain.current) {
      dryGain.current.gain.setTargetAtTime(1 - reverbAmount, audioCtx.current.currentTime, 0.05);
      wetGain.current.gain.setTargetAtTime(reverbAmount, audioCtx.current.currentTime, 0.05);
    }

    // Update Output
    if (outputGainNode.current) {
      outputGainNode.current.gain.setTargetAtTime(Math.pow(10, outputGain / 20), audioCtx.current.currentTime, 0.05);
    }

    // Update Source Playback Rate
    if (sourceNode.current) {
      sourceNode.current.playbackRate.setTargetAtTime(speed, audioCtx.current.currentTime, 0.05);
    }
  }, [eqGains, reverbAmount, outputGain, speed, preDelay, dampingLF, dampingHF, width]);

  useEffect(() => {
    updateAudioNodes();
  }, [updateAudioNodes]);

  // --- 3D Orbit Animation ---
  useEffect(() => {
    let angle = 0;
    const animate = () => {
      if (isPlaying && pannerNode.current && audioCtx.current) {
        angle += orbitSpeed * 0.05;
        const pan = Math.sin(angle) * directionality;
        pannerNode.current.pan.setTargetAtTime(pan, audioCtx.current.currentTime, 0.1);
      }
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(animationFrameRef.current);
  }, [isPlaying, orbitSpeed, directionality]);

  // --- Playback Controls ---
  const play = (startTime = offsetRef.current) => {
    if (!audioCtx.current || !audioBuffer) return;
    
    if (audioCtx.current.state === 'suspended') {
      audioCtx.current.resume();
    }

    sourceNode.current = audioCtx.current.createBufferSource();
    sourceNode.current.buffer = audioBuffer;
    sourceNode.current.playbackRate.value = speed;
    
    // Routing: Source -> EQ Chain -> Reverb Split -> Panner -> Output -> Destination
    let lastNode: AudioNode = sourceNode.current;
    
    // EQ Chain
    eqNodes.current.forEach(node => {
      lastNode.connect(node);
      lastNode = node;
    });

    // Reverb Path
    if (dryGain.current && wetGain.current && reverbNode.current && preDelayNode.current && dampingLFNode.current && dampingHFNode.current) {
      lastNode.connect(dryGain.current);
      
      lastNode.connect(preDelayNode.current);
      preDelayNode.current.connect(reverbNode.current);
      reverbNode.current.connect(dampingLFNode.current);
      dampingLFNode.current.connect(dampingHFNode.current);
      dampingHFNode.current.connect(wetGain.current);
      
      const mixNode = audioCtx.current.createGain();
      dryGain.current.connect(mixNode);
      wetGain.current.connect(mixNode);
      lastNode = mixNode;
    }

    // Panner
    if (pannerNode.current) {
      lastNode.connect(pannerNode.current);
      lastNode = pannerNode.current;
    }

    // Output
    if (outputGainNode.current) {
      lastNode.connect(outputGainNode.current);
      lastNode = outputGainNode.current;
    }

    lastNode.connect(audioCtx.current.destination);

    sourceNode.current.start(0, startTime);
    startTimeRef.current = audioCtx.current.currentTime - (startTime / speed);
    setIsPlaying(true);

    sourceNode.current.onended = () => {
      if (audioCtx.current && Math.abs(currentTime - duration) < 0.1) {
        setIsPlaying(false);
        offsetRef.current = 0;
        setCurrentTime(0);
      }
    };
  };

  const stop = () => {
    if (sourceNode.current) {
      sourceNode.current.stop();
      sourceNode.current.disconnect();
    }
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (isPlaying) {
      offsetRef.current = currentTime;
      stop();
    } else {
      play();
    }
  };

  const handleSeek = (time: number) => {
    const wasPlaying = isPlaying;
    if (wasPlaying) stop();
    offsetRef.current = time;
    setCurrentTime(time);
    if (wasPlaying) play(time);
  };

  // --- File Handling ---
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !audioCtx.current) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const arrayBuffer = event.target?.result as ArrayBuffer;
      const buffer = await audioCtx.current!.decodeAudioData(arrayBuffer);
      setAudioBuffer(buffer);
      setDuration(buffer.duration);
      setCurrentTime(0);
      offsetRef.current = 0;
      if (isPlaying) stop();
    };
    reader.readAsArrayBuffer(file);
  };

  // --- Progress Tracking ---
  useEffect(() => {
    if (!isPlaying || !audioCtx.current) return;

    const updateProgress = () => {
      if (audioCtx.current) {
        const elapsed = (audioCtx.current.currentTime - startTimeRef.current) * speed;
        setCurrentTime(Math.min(elapsed, duration));
      }
      if (isPlaying) {
        requestAnimationFrame(updateProgress);
      }
    };
    updateProgress();
  }, [isPlaying, speed, duration]);

  // --- Handlers ---
  const handleSpeedChange = (val: number) => {
    setSpeed(val);
    if (isLocked) {
      // Map speed to pitch (logarithmic relation)
      // Speed 1.0 = Pitch 0
      // Speed 0.5 = Pitch -12 (one octave down)
      const semitones = 12 * Math.log2(val);
      setPitch(semitones);
    }
  };

  const handlePitchChange = (val: number) => {
    setPitch(val);
    if (isLocked) {
      const newSpeed = Math.pow(2, val / 12);
      setSpeed(newSpeed);
    }
  };

  return (
    <div className="min-h-screen bg-[#0f1117] text-gray-100 font-sans selection:bg-cyan-500/30">
      <div className="max-w-4xl mx-auto px-4 py-8 md:py-12">
        
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Waves className="text-white" size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-white">Slowed & Reverb <span className="text-cyan-400">Studio</span></h1>
              <p className="text-gray-500 text-sm font-medium uppercase tracking-widest">Premium Audio Processor</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 px-4 py-2.5 bg-gray-800 hover:bg-gray-700 rounded-lg cursor-pointer transition-all border border-gray-700 hover:border-cyan-500/50 group">
              <Upload size={18} className="text-cyan-400 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-semibold">Upload Track</span>
              <input type="file" accept="audio/*" onChange={handleFileUpload} className="hidden" />
            </label>
            <button 
              onClick={handleDownload}
              disabled={!audioBuffer}
              className="flex items-center gap-2 px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 disabled:bg-gray-800 disabled:text-gray-600 disabled:border-gray-700 text-gray-900 rounded-lg font-bold transition-all shadow-lg shadow-cyan-500/20 disabled:shadow-none"
            >
              <Download size={18} />
              <span className="text-sm">Download</span>
            </button>
          </div>
        </header>

        {/* Main Player Card */}
        <main className="bg-gray-900/40 border border-purple-500/20 rounded-3xl p-6 md:p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
          {/* Subtle background glow */}
          <div className="absolute -top-24 -right-24 w-64 h-64 bg-cyan-500/10 blur-[100px] rounded-full" />
          <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-purple-500/10 blur-[100px] rounded-full" />

          {/* Player Top Section */}
          <div className="flex flex-col md:flex-row items-center gap-8 mb-10">
            <button 
              onClick={togglePlay}
              disabled={!audioBuffer}
              className="w-20 h-20 flex-shrink-0 bg-transparent border-2 border-cyan-400 rounded-full flex items-center justify-center text-cyan-400 hover:bg-cyan-400 hover:text-gray-900 transition-all shadow-[0_0_20px_rgba(0,245,212,0.2)] disabled:opacity-30 disabled:cursor-not-allowed group"
            >
              {isPlaying ? <Pause size={32} fill="currentColor" /> : <Play size={32} fill="currentColor" className="ml-1" />}
            </button>

            <div className="flex-grow w-full">
              <div className="flex justify-between items-end mb-2">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-cyan-500 uppercase tracking-widest mb-1">Now Playing</span>
                  <h2 className="text-lg font-semibold text-white truncate max-w-[200px] md:max-w-md">
                    {fileName || "No track selected"}
                  </h2>
                </div>
                <div className="text-xs font-mono text-gray-400">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </div>
              </div>
              <Waveform 
                audioBuffer={audioBuffer} 
                currentTime={currentTime} 
                duration={duration} 
                onSeek={handleSeek} 
              />
            </div>
          </div>

          {/* Tabs Navigation */}
          <nav className="flex flex-wrap items-center gap-1 bg-gray-950/50 p-1 rounded-xl mb-8 border border-gray-800">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                  activeTab === tab.id 
                    ? 'bg-cyan-500 text-gray-900 shadow-lg' 
                    : 'text-gray-400 hover:text-gray-200 hover:bg-gray-800'
                }`}
              >
                {tab.icon}
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </nav>

          {/* Tab Content */}
          <div className="min-h-[280px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
                className="w-full"
              >
                {activeTab === 'main' && (
                  <div className="flex flex-col gap-8 py-4">
                    <Slider 
                      label="Speed" 
                      value={speed} 
                      min={0.5} 
                      max={1.5} 
                      onChange={handleSpeedChange}
                      showLock
                      isLocked={isLocked}
                      onToggleLock={() => setIsLocked(!isLocked)}
                    />
                    <Slider 
                      label="Pitch" 
                      value={pitch} 
                      min={-12} 
                      max={12} 
                      unit=" st"
                      onChange={handlePitchChange}
                    />
                    <Slider 
                      label="Reverb Amount" 
                      value={reverbAmount} 
                      min={0} 
                      max={1} 
                      onChange={setReverbAmount}
                    />
                    <div className="mt-4 p-4 bg-cyan-500/5 border border-cyan-500/20 rounded-xl flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
                        <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">Impulse Response</span>
                      </div>
                      <button className="text-[10px] font-mono bg-gray-800 px-3 py-1 rounded border border-gray-700 text-gray-300 hover:border-cyan-500 transition-colors">
                        "Elve Den Cloakroom"
                      </button>
                    </div>
                  </div>
                )}

                {activeTab === 'advanced' && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8">
                    <Knob label="Pre-Delay" value={preDelay} min={0} max={200} unit="ms" onChange={setPreDelay} />
                    <Knob label="Width" value={width} min={0} max={200} unit="%" onChange={setWidth} />
                    <Knob label="Damping LF" value={dampingLF} min={-24} max={0} unit="dB" onChange={setDampingLF} />
                    <Knob label="Damping HF" value={dampingHF} min={-24} max={0} unit="dB" onChange={setDampingHF} />
                  </div>
                )}

                {activeTab === 'eq' && (
                  <div className="grid grid-cols-3 md:grid-cols-6 gap-6 py-8">
                    <Knob label="Bass" value={eqGains[0]} min={-12} max={12} unit="dB" onChange={(v) => {
                      const newGains = [...eqGains];
                      newGains[0] = v;
                      setEqGains(newGains);
                    }} />
                    <Knob label="Low-Mid" value={eqGains[1]} min={-12} max={12} unit="dB" onChange={(v) => {
                      const newGains = [...eqGains];
                      newGains[1] = v;
                      setEqGains(newGains);
                    }} />
                    <Knob label="Mid" value={eqGains[2]} min={-12} max={12} unit="dB" onChange={(v) => {
                      const newGains = [...eqGains];
                      newGains[2] = v;
                      setEqGains(newGains);
                    }} />
                    <Knob label="High-Mid" value={eqGains[3]} min={-12} max={12} unit="dB" onChange={(v) => {
                      const newGains = [...eqGains];
                      newGains[3] = v;
                      setEqGains(newGains);
                    }} />
                    <Knob label="Treble" value={eqGains[4]} min={-12} max={12} unit="dB" onChange={(v) => {
                      const newGains = [...eqGains];
                      newGains[4] = v;
                      setEqGains(newGains);
                    }} />
                    <Knob label="Output" value={outputGain} min={-24} max={12} unit="dB" onChange={setOutputGain} color="#a855f7" />
                  </div>
                )}

                {activeTab === 'orbit' && (
                  <div className="flex flex-col gap-8 py-4">
                    <Slider label="Orbit Speed" value={orbitSpeed} min={0} max={2} onChange={setOrbitSpeed} />
                    <Slider label="Vertical Oscillation" value={oscillation} min={0} max={1} onChange={setOscillation} />
                    <Slider label="Directionality" value={directionality} min={0} max={1} onChange={setDirectionality} />
                    <div className="mt-4 flex items-center gap-2 text-xs text-gray-500 italic">
                      <Globe size={12} />
                      Spatial audio processing active. Use headphones for best effect.
                    </div>
                  </div>
                )}

                {activeTab === 'presets' && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 py-4">
                    {[
                      { name: 'Classic Slowed', speed: 0.85, reverb: 0.6, eq: [4, 0, -2, -1, -2] },
                      { name: 'Deep Ethereal', speed: 0.75, reverb: 0.85, eq: [6, 2, -4, -2, -4] },
                      { name: 'Nightcore', speed: 1.25, reverb: 0.2, eq: [-2, 0, 2, 4, 2] },
                      { name: 'Study Focus', speed: 0.92, reverb: 0.3, eq: [1, 0, 0, -1, -3] },
                      { name: 'Midnight Drive', speed: 0.88, reverb: 0.45, eq: [5, 1, -1, 2, 3] },
                      { name: 'Romantic Bliss', speed: 0.82, reverb: 0.7, eq: [3, 4, 2, 0, -2] },
                      { name: 'Deep Sadness', speed: 0.7, reverb: 0.9, eq: [4, 0, -4, -6, -8] },
                      { name: 'Lo-Fi Chill', speed: 0.9, reverb: 0.4, eq: [2, 1, 0, -2, -6] },
                      { name: 'DJ Beats', speed: 1.05, reverb: 0.25, eq: [6, 0, -2, 3, 5] },
                      { name: 'Bass Proper S&R', speed: 0.78, reverb: 0.8, eq: [10, 4, -2, -4, -6] },
                      { name: 'Vaporwave', speed: 0.8, reverb: 0.7, eq: [3, 0, 0, 2, 4] },
                      { name: 'Reset All', speed: 1.0, reverb: 0.0, eq: [0, 0, 0, 0, 0] },
                    ].map((preset) => (
                      <button
                        key={preset.name}
                        onClick={() => {
                          setSpeed(preset.speed);
                          setReverbAmount(preset.reverb);
                          setEqGains(preset.eq);
                          if (isLocked) setPitch(12 * Math.log2(preset.speed));
                        }}
                        className="p-4 bg-gray-800/50 border border-gray-700 rounded-xl text-sm font-bold hover:border-cyan-500/50 hover:bg-gray-800 transition-all text-gray-300 hover:text-cyan-400"
                      >
                        {preset.name}
                      </button>
                    ))}
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>

        {/* Footer Info */}
        <footer className="mt-12 text-center">
          <p className="text-gray-600 text-[10px] uppercase tracking-[0.2em] font-bold">
            This is a trial version of our Premium tool. It uploads the full track so you can try all features.
          </p>
          <div className="mt-4 flex justify-center gap-6">
            <a href="#" className="text-gray-500 hover:text-cyan-400 transition-colors text-xs font-bold uppercase tracking-widest">Privacy</a>
            <a href="#" className="text-gray-500 hover:text-cyan-400 transition-colors text-xs font-bold uppercase tracking-widest">Terms</a>
            <a href="#" className="text-gray-500 hover:text-cyan-400 transition-colors text-xs font-bold uppercase tracking-widest">Contact</a>
          </div>
        </footer>
      </div>
    </div>
  );
}

// --- Utility Functions ---
function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

import React, { useRef, useEffect } from 'react';

interface WaveformProps {
  audioBuffer: AudioBuffer | null;
  currentTime: number;
  duration: number;
  onSeek: (time: number) => void;
}

export const Waveform: React.FC<WaveformProps> = ({
  audioBuffer,
  currentTime,
  duration,
  onSeek,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !audioBuffer) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const data = audioBuffer.getChannelData(0);
    const step = Math.ceil(data.length / width);
    const amp = height / 2;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#374151'; // Base color

    for (let i = 0; i < width; i++) {
      let min = 1.0;
      let max = -1.0;
      for (let j = 0; j < step; j++) {
        const datum = data[i * step + j];
        if (datum < min) min = datum;
        if (datum > max) max = datum;
      }
      
      const barHeight = (max - min) * amp;
      const y = (1 + min) * amp;
      
      // Draw base bar
      ctx.fillRect(i, y, 1, Math.max(1, barHeight));
    }

    // Draw progress overlay
    const progressWidth = (currentTime / duration) * width;
    ctx.fillStyle = '#00f5d4'; // Progress color
    ctx.globalCompositeOperation = 'source-atop';
    ctx.fillRect(0, 0, progressWidth, height);
    ctx.globalCompositeOperation = 'source-over';

  }, [audioBuffer, currentTime, duration]);

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || !duration) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const seekTime = (x / rect.width) * duration;
    onSeek(seekTime);
  };

  return (
    <div className="relative w-full h-24 bg-gray-900/50 rounded-lg overflow-hidden border border-gray-800">
      <canvas
        ref={canvasRef}
        width={800}
        height={96}
        className="w-full h-full cursor-pointer"
        onClick={handleClick}
      />
      {!audioBuffer && (
        <div className="absolute inset-0 flex items-center justify-center text-gray-600 text-sm font-medium uppercase tracking-widest">
          Upload a track to visualize
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Lock, Unlock } from 'lucide-react';

interface SliderProps {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  onChange: (value: number) => void;
  isLocked?: boolean;
  onToggleLock?: () => void;
  showLock?: boolean;
}

export const Slider: React.FC<SliderProps> = ({
  label,
  value,
  min,
  max,
  step = 0.01,
  unit = '',
  onChange,
  isLocked = false,
  onToggleLock,
  showLock = false,
}) => {
  const percentage = ((value - min) / (max - min)) * 100;

  return (
    <div className="flex flex-col gap-4 w-full group">
      <div className="flex justify-between items-center px-1">
        <span className="text-sm font-medium text-gray-300 uppercase tracking-wider">{label}</span>
        <div className="flex items-center gap-2">
          {showLock && onToggleLock && (
            <button
              onClick={onToggleLock}
              className={`p-1 rounded-full transition-colors ${
                isLocked ? 'text-cyan-400 bg-cyan-400/10' : 'text-gray-500 hover:text-gray-400'
              }`}
            >
              {isLocked ? <Lock size={14} /> : <Unlock size={14} />}
            </button>
          )}
          <span className="text-xs font-mono text-cyan-400">
            {value.toFixed(2)}{unit}
          </span>
        </div>
      </div>
      
      <div className="relative h-1.5 w-full bg-gray-800 rounded-full overflow-hidden">
        <div 
          className="absolute top-0 left-0 h-full bg-cyan-400/80 shadow-[0_0_10px_rgba(0,245,212,0.5)] transition-all duration-75"
          style={{ width: `${percentage}%` }}
        />
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer z-10"
        />
      </div>
    </div>
  );
};

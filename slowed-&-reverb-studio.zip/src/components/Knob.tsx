import React, { useState, useEffect, useRef } from 'react';

interface KnobProps {
  label: string;
  value: number;
  min: number;
  max: number;
  unit?: string;
  onChange: (value: number) => void;
  color?: string;
}

export const Knob: React.FC<KnobProps> = ({
  label,
  value,
  min,
  max,
  unit = '',
  onChange,
  color = '#00f5d4',
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const startY = useRef(0);
  const startValue = useRef(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    startY.current = e.clientY;
    startValue.current = value;
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    startY.current = e.touches[0].clientY;
    startValue.current = value;
  };

  useEffect(() => {
    const handleMove = (clientY: number) => {
      if (!isDragging) return;
      const deltaY = startY.current - clientY;
      const range = max - min;
      const step = range / 200; // Sensitivity
      let newValue = startValue.current + deltaY * step;
      newValue = Math.max(min, Math.min(max, newValue));
      onChange(newValue);
    };

    const handleMouseMove = (e: MouseEvent) => handleMove(e.clientY);
    const handleTouchMove = (e: TouchEvent) => {
      if (e.cancelable) e.preventDefault();
      handleMove(e.touches[0].clientY);
    };

    const handleEnd = () => {
      setIsDragging(false);
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleEnd);
      window.addEventListener('touchmove', handleTouchMove, { passive: false });
      window.addEventListener('touchend', handleEnd);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleEnd);
      window.removeEventListener('touchmove', handleTouchMove);
      window.removeEventListener('touchend', handleEnd);
    };
  }, [isDragging, min, max, onChange]);

  const rotation = ((value - min) / (max - min)) * 270 - 135;

  return (
    <div className="flex flex-col items-center gap-2 select-none">
      <span className="text-xs font-medium text-gray-400 uppercase tracking-wider">{label}</span>
      <div
        className="relative w-16 h-16 cursor-ns-resize touch-none"
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
      >
        {/* Background Circle */}
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="32"
            cy="32"
            r="28"
            fill="none"
            stroke="#1f2937"
            strokeWidth="4"
          />
          {/* Active Progress */}
          <circle
            cx="32"
            cy="32"
            r="28"
            fill="none"
            stroke={color}
            strokeWidth="4"
            strokeDasharray={`${(value - min) / (max - min) * 175.9} 175.9`}
            className="transition-all duration-75"
          />
        </svg>
        
        {/* Knob Inner */}
        <div 
          className="absolute inset-2 bg-gray-800 rounded-full shadow-inner flex items-center justify-center border border-gray-700"
          style={{ transform: `rotate(${rotation}deg)` }}
        >
          <div className="w-1 h-4 bg-cyan-400 rounded-full absolute top-1" />
        </div>
      </div>
      <span className="text-[10px] font-mono text-cyan-400">
        {value.toFixed(value < 10 ? 1 : 0)}{unit}
      </span>
    </div>
  );
};
